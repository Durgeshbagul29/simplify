/**
 * Simple script to verify if the Gemini API key is working
 */

async function verifyApiKey() {
    const API_KEY = 'AIzaSyBpHF60Yx0KQ0fdJCmhfFbwVKhWekZBdbE';
    const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${API_KEY}`;
    
    console.log('Testing Gemini API key...');
    
    try {
        // Simple test prompt
        const requestBody = {
            contents: [{
                parts: [{
                    text: "Hello, this is a test message. Please respond with 'API key verification successful'."
                }]
            }],
            generationConfig: {
                temperature: 0.7,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 100,
            }
        };

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        console.log('Response status:', response.status);
        console.log('Response status text:', response.statusText);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('API request failed:', errorText);
            return false;
        }

        const data = await response.json();
        console.log('API response:', JSON.stringify(data, null, 2));
        
        if (data.candidates && data.candidates[0] && data.candidates[0].content) {
            const responseText = data.candidates[0].content.parts[0].text;
            console.log('✅ API key verification successful!');
            console.log('Response:', responseText);
            return true;
        } else {
            console.error('❌ No response content received from Gemini API');
            return false;
        }
    } catch (error) {
        console.error('❌ API key verification failed:', error.message);
        return false;
    }
}

// Run the verification
verifyApiKey().then(success => {
    if (success) {
        console.log('🎉 Your Gemini API key is working correctly!');
    } else {
        console.log('⚠️  There may be an issue with your Gemini API key.');
        console.log('Please check:');
        console.log('1. If your API key is valid and active');
        console.log('2. If there are any network restrictions');
        console.log('3. If the Gemini API is accessible from your location');
    }
});