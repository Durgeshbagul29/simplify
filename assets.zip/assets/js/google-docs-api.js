/**
 * Google Docs API Integration for Samplify Chatbot
 * 
 * This module handles fetching custom knowledge from Google Docs
 * to enhance the Gemini API responses with domain-specific information.
 */

// Google Docs document ID - Replace with your actual document ID
// Format: https://docs.google.com/document/d/DOCUMENT_ID/edit
const GOOGLE_DOC_ID = '1_b1hnQ4hyelVgfj1ft2Xv6yfI8-CqkKHzI7A4m7FYZM';

/**
 * Fetch content from a Google Doc
 * Note: This requires the document to be publicly accessible or use proper authentication
 * For simplicity in this implementation, we're assuming public access
 * 
 * @returns {Promise<string>} The content of the Google Doc
 */
async function fetchGoogleDocContent() {
    try {
        console.log('Fetching Google Doc content with ID:', GOOGLE_DOC_ID);
        // For a publicly accessible Google Doc, we can fetch it as text
        // Note: This is a simplified approach. For private docs, you'd need OAuth2 authentication
        const url = `https://docs.google.com/document/export?format=txt&id=${GOOGLE_DOC_ID}`;
        console.log('Fetching from URL:', url);
        const response = await fetch(url);
        
        console.log('Google Doc fetch response:', response.status, response.statusText);
        
        if (!response.ok) {
            throw new Error(`Failed to fetch Google Doc: ${response.status} ${response.statusText}`);
        }
        
        const content = await response.text();
        console.log('Google Doc content length:', content.length);
        
        // Simple processing to clean up the text content
        // Remove excessive newlines and whitespace
        // For now, just return the content as-is
        return content.trim();
    } catch (error) {
        console.error('Error fetching Google Doc content:', error);
        // Return empty string or default content if fetch fails
        return '';
    }
}

/**
 * Process Google Doc content to extract relevant knowledge
 * This is a simple implementation that returns the full content
 * In a more advanced implementation, you might parse sections, headers, etc.
 * 
 * @returns {Promise<string>} Processed knowledge content
 */
async function getCustomKnowledge() {
    try {
        const docContent = await fetchGoogleDocContent();
        // In a more advanced implementation, you might:
        // - Parse the document structure
        // - Extract specific sections
        // - Create embeddings for semantic search
        // - Cache the content for performance
        
        return docContent;
    } catch (error) {
        console.error('Error getting custom knowledge:', error);
        return '';
    }
}

/**
 * Enhanced Gemini API function that incorporates custom knowledge
 * 
 * @param {string} prompt - The user's message
 * @param {object} userData - User information (name, phone, address)
 * @returns {Promise<string>} The AI response enhanced with custom knowledge
 */
async function getEnhancedGeminiResponse(prompt, userData) {
    try {
        // Get custom knowledge from Google Docs
        const customKnowledge = await getCustomKnowledge();
        console.log('Custom knowledge fetched:', customKnowledge ? 'Content available' : 'No content', customKnowledge?.length || 0, 'characters');
        
        // Enhanced context for the AI about Samplify with custom knowledge
        // Limit the custom knowledge to prevent excessively large requests
        const maxKnowledgeLength = 5000;
        const limitedKnowledge = customKnowledge && customKnowledge.length > maxKnowledgeLength 
            ? customKnowledge.substring(0, maxKnowledgeLength) + '... (content truncated)'
            : customKnowledge || '';
            
        const context = `You are a helpful assistant for Samplify, an environmental sampling solution. 
        The user's name is ${userData.name}, phone is ${userData.phone}, and address is ${userData.address}.
        Samplify provides water and air quality testing solutions with real-time data entry, GPS capabilities, and comprehensive reporting.
        The app supports multiple sample types including Water/Effluent, Ambient Air/Fugitive Emissions, Stack Emission, Environmental, Air/Swabs, Food, Noise, Solid Waste, and more.
        Users can download the mobile app from Google Play Store.
        
        CUSTOM KNOWLEDGE BASE FROM GOOGLE DOCS:
        ${limitedKnowledge || ''}`;
        
        // Use the existing Gemini API key and URL from gemini-api.js
        const GEMINI_API_KEY = 'AIzaSyBpHF60Yx0KQ0fdJCmhfFbwVKhWekZBdbE'; // This should match gemini-api.js
        // Using the correct model name for Gemini API
        const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
        
        const requestBody = {
            contents: [{
                parts: [{
                    text: `${context}\n\nUser: ${prompt}\nAssistant:`
                }]
            }],
            generationConfig: {
                temperature: 0.7,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 1024,
            }
        };

        // Debug information
        console.log('Enhanced Gemini API Request:', {
            url: GEMINI_API_URL,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: requestBody
        });
        
        const response = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        
        console.log('Enhanced Gemini API Response:', {
            status: response.status,
            statusText: response.statusText
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`API request failed with status ${response.status}: ${errorText}`);
        }

        const data = await response.json();
        
        if (data.candidates && data.candidates[0] && data.candidates[0].content) {
            return data.candidates[0].content.parts[0].text;
        } else {
            throw new Error('No response content received from Gemini API');
        }
    } catch (error) {
        console.error('Error getting enhanced Gemini response:', error);
        throw error;
    }
}

// Export functions for use in other modules
window.GoogleDocsAPI = {
    fetchGoogleDocContent,
    getCustomKnowledge,
    getEnhancedGeminiResponse
};